package srp;

public class CalcApp {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle (5, 5);
        System.out.format("Area = %d\n", rect.getArea());
    }
}
