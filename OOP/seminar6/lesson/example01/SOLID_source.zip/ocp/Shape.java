package ocp;

public interface Shape {
    void draw ();
}
