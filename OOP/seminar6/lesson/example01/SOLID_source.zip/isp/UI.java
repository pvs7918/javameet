package isp;

public interface UI {
    int getWithdrawSum ();
    int getDepositSum ();
    int getTransferSum ();
    String getTransferTarget ();
}
