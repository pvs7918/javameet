package srp;

public class GraphicalApp {
    public static void main(String[] args) {
        GraphicRectangle rect = new GraphicRectangle(6, 6);
        rect.draw();
    }
}
